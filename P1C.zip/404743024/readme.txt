Project 1B

Name: Reinaldo Daniswara, Tianyang Zhang
UID : 604840665, 404743024

We met all the criteria of the project requirement: searching and display information of actors and movies(click names to go to specific actor/movie info page), add actor/director, add movie information, add movie/actor relation, add movie/director relation, and add review. We also use some CSS code to improved the UI of our website. 

Reinaldo worked on Add Actor/Direcor, Add Movie Info, Add Review, and using CSS to makes the UI looks much better.
Tianyang worked on Searching, display actor/movie info, hyperlink to specific actor/movie info page, and add relation between movie/actor and movie/director.